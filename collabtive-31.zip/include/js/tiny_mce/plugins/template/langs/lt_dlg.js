tinyMCE.addI18n('lt.template_dlg',{
title:"\u0160ablonai",
label:"\u0160ablonas",
desc_label:"Apra\u0161ymas",
desc:"\u012Eterpti jau nustatyt\u0105 \u0161ablonin\u012F turin\u012F",
select:"Pasirinkti \u0161ablon\u0105",
preview:"Per\u017Ei\u016Bra",
warning:"Persp\u0117jimas: \u0160ablono pakeitimas kitu gali sukelti duomen\u0173 praradim\u0105.",
mdate_format:"%Y-%m-%d %H:%M:%S",
cdate_format:"%Y-%m-%d %H:%M:%S",
months_long:"Sausis,Vasaris,Kovas,Balandis,Gegu\u017E\u0117,Bir\u017Eelis,Liepa,Rugpj\u016Btis,Rugs\u0117jis,Spalis,Lapkritis,Gruodis",
months_short:"Sau,Vas,Kov,Bal,Geg,Bir,Lie,Rugpj,Rugs,Spa,Lapkr,Gruo",
day_long:"Sekmadienis,Pirmadienis,Antradienis,Tre\u010Diadienis,Ketvirtadienis,Penktadienis,\u0160e\u0161tadienis,Sekmadienis",
day_short:"Sekm,Pirm,Antr,Tre\u010D,Ketv,Penk,\u0160e\u0161t,Sekm"
});