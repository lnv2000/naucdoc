var searchwidgetComponent = Vue.extend({
	props: ["searchtitle"],
	template: ""
});

Vue.component("searchwidget", searchwidgetComponent);