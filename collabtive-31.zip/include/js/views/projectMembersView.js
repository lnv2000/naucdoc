var projectMembers = {
    el: "projectMembers",
    itemType: "user",
    url: "manageuser.php?action=projectMembers",
    dependencies: []
};
pagination.itemsPerPage = 21;
var projectMembersView;