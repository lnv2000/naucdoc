<?php

//we shouldn't get here...
die('Direct access to setup directory is not permitted' );

?>