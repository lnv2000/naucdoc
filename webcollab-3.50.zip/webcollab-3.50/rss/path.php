<?php

//set the include path in case the default has been altered
ini_set('include_path', '.' );

//set the base directory
define('BASE', '../' );

?>