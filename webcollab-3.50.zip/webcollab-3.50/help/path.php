<?php

define('BASE', '../' );

?>