<?php

//we shouldn't get here...
die('Direct access to includes directory is not permitted' );

?>