<?php

require_once('path.php');

//path to config file
define('BASE_CONFIG', BASE.'config/' );
//path to CSS files
define('BASE_CSS', BASE.'css/' );

?>