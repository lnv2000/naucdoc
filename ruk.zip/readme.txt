RUKOVODITEL

  Open Source Web Application Designer for Business.

INSTALLATION

  Rukovoditel is web application, and it means that you have to have a web server.
  Simply go to your Rukovoditel web directory and use installer.
  Read more https://docs.rukovoditel.net/index.php?p=6
  
  Install Rukovoditel on local pc
  https://docs.rukovoditel.net/index.php?p=5

SUPPORT

  My name is Sergey Kharchishin. I always reply to emails within 24-48 hours.
         
  Report the bug on the project's forum. 
  http://forum.rukovoditel.net/viewforum.php?f=6
  
  Contact me (support@rukovoditel.net) if you have any questions, suggestions or 
  feedback about Rukovoditel.
    
NOTICE OF LICENSE

  These source files are subject to the GNU GPLv2
  that is bundled with this package in the file LICENSE.txt.
  It is also available through the world-wide-web at this URL:
  https://www.gnu.org/licenses/gpl-2.0.html
  https://tldrlegal.com/license/gnu-general-public-license-v2

  
@copyright  Copyright (c) Sergey Kharchishin (http://www.rukovoditel.net)
@license    https://www.gnu.org/licenses/gpl-2.0.html  GNU GPLv2

THANKS FOR DOWNLOADING AND USING RUKOVODITEL OPEN-SOURCE SOLUTION!
